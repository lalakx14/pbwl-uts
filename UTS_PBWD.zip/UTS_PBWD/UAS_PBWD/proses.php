<?php

include"koneksi.php";

if(isset($_POST['btn_proses'])) {
    $reg_nis = $_POST['reg_nis'];
    $reg_nama = $_POST['reg_nama'];
    $reg_tptlahir = $_POST['reg_tptlahir'];
    $reg_tgllahir = $_POST['reg_tgllahir'];
    $reg_alamat = $_POST['reg_alamat'];
    $reg_nohp = $_POST['reg_nohp'];

    $sql = "INSERT INTO tb_registrasi VALUES (NULL, :reg_nis, :reg_nama, :reg_tptlahir, :reg_tgllahir, :reg_alamat, :reg_nohp )"; 

$stmt = $koneksi->prepare($sql);

$stmt->bindParam(":reg_nis", $reg_nis);
$stmt->bindParam(":reg_nama", $reg_nama);
$stmt->bindParam(":reg_tptlahir", $reg_tptlahir);
$stmt->bindParam(":reg_tgllahir", $reg_tgllahir);
$stmt->bindParam(":reg_alamat", $reg_alamat);
$stmt->bindParam(":reg_nohp", $reg_nohp);

$stmt->execute();

header("location: index.php?page=info");
}
