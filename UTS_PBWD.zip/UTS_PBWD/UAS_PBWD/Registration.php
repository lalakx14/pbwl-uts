<H3>Formulir Registrasi</H3>
<form action="proses.php" method="post">
    <table>
        <tr>
            <td>NIS</td>
            <td><input type="text" name="reg_nis"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="reg_nama"></td>
        </tr>
        <tr>
            <td>TEMPAT LAHIR</td>
            <td><input type="text" name="reg_tptlahir"></td>
        </tr>
        </tr><tr>
            <td>TANGGAL LAHIR</td>
            <td><input type="date" name="reg_tgllahir"></td>
        </tr><tr>
        <tr>
            <td>ALAMAT</td>
            <td><input type="text" name="reg_alamat"></td>
        </tr>
        <tr>
            <td>NOMOR HANDPHONE</td>
            <td><input type="text" name="reg_nohp"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_proses" value="SIMPAN"></td>
        </tr>
    </table>
</form>


