<h3> MTs Al Washliyah Medan Krio </h3>
Madrasah Tsanawiyah Al Washliyah Medan Krio Kecamatan Sunggal Berdiri pada tahun 1974 yang dahulu bernama PGAP/4 tahun, 
dengan kepala Madrasah Alm. M. Amin (1974 s/d 1978) Madrasah ini berada satu lokasi dengan MIS Al Washliyah Medan Krio 
yang sudah berdiri sejak tahun 1957. Pada tahun 1978, dengan SKB 3 Menteri Madrasah ini berubah nama menjadi MTs Al Washliyah 
Medan Krio (ExPGAP/4 tahun) dan menyelenggarakan ujian Negara pertama Sekali pada tahun 1978. Madrasah Tsanawiyah Medan 
Krio ini berlokasi di komplek Masjid JAMI’ Medan Krio sampai tahun 1984, dan pada tahun berikutnya berpindah lokasi ke komplek 
MIS Al Washliyah Medan krio diatas tanah Wakaf Drs. H. Saidan, sampai sekarang yang mana bangunannya sudah berdiri atas 
sumbangsi beberapa donatur dan subsidi pemerintahan, baik dari DEPAG maupun dari DINAS Pendidikan Nasional. Pada tahun-tahun 
pertama ujian Negara, Madrasah ini menumpang pada Madrasah penyelenggara dan Madrasah ini pernah menjadi Rayon penyelenggara 
ujian Nasional.