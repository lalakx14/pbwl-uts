<!DOCTYPE html>
<html lang="en">
<head>
    <title>MTs Al - Washliyah</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <main>
    <header>
        <img src="assets/image/logo.jpg" alt="IMG" id="gam">
        <h1 class="jumbotron">  </h1>
    </header>
    <nav>
        <ul>
            <li>
                <a href="index.php"class="active">Home</a> 
            </li>
            <li>
            <a href="index.php?page=Registration">Registration</a> 
            </li> 
            <li>
                <a href="index.php?page=info">Info</a> 
            </li>
            <li>
                <a href="index.php?page=about">About</a>
            </li>
            <li>
                <a href="index.php?page=edit.php"></a>
            </li>     
        </ul>
    </nav>
    <section>
    <?php  
    if (isset($_GET['page'])) {
            include $_GET['page'] . ".php";
        } else {
            include "main.php ";
        }
        ?>
    </section>
    <footer>
        Copyright &copy; 2021
    </footer>
    </main>
</body>
</html>