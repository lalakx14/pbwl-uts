<?php
include "koneksi.php";
$sql = "SELECT * FROM tb_registrasi";
$stmt = $koneksi->prepare($sql);
$stmt->execute();
?>
  <h3> Data Calon Murid Baru</h3>
  <table>
      <tr>
          <th>NO</th>
          <th>NIS</th>
          <th>NAMA</th>
          <th>TEMPAT LAHIR</th>
          <th>TANGGAL LAHIR</th>
          <th>ALAMAT</th>
          <th>NOMOR HANDPHONE</th>
          <th>PILIHAN</th>
        </tr>

        <?php while ($row = $stmt->fetch()) { ?>
        
        <tr>
            <td><?php echo $row['reg_id'] ?></td>
            <td><?php echo $row['reg_nis'] ?></td>
            <td><?php echo $row['reg_nama'] ?></td>
            <td><?php echo $row['reg_tptlahir'] ?></td>
            <td><?php echo $row['reg_tgllahir'] ?></td>
            <td><?php echo $row['reg_alamat'] ?></td>
            <td><?php echo $row['reg_nohp'] ?></td> 
            <td>
            <a href="index.php?delete=<?php echo $row['reg_id'];?>">delete</a>
            </td>
        </tr>

        <?php } ?>
     </table>
        