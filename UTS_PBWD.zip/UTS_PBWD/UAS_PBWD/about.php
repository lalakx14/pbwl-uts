<section class="card">
<img src="assets/image/profil.png" alt="IMG" id="gam">
<h4> NAMA : Giri Restu Adjie</4>
<h4> NIM : 0702181069</4>
<h4> Kelas : Sistem Informasi 3</4>